//Mohammed Afra Adeeb
//999993905

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.event.ActionListener; 
import java.util.Random;
import javax.imageio.ImageIO;

import  sun.audio.*;    //import the sun.audio package
import  java.io.*;

class done{
	
	public static int comple=0;
 	public static void setcomple(int com)
		{
			comple=com;
	
		}	
		public static int getcomple()
		{
			return comple;
		}
	
}


class MineSweeper
{
private JFrame main_frm1;
private JPanel gui_mines;
private JButton[] level_but=new JButton[3];
private String[] difficulty=new String[]{"Beginner","Advanced","Expert"};
private JLabel lab;
private String[] level_difficulty=new String[]{"8","16","24"};
private String[] level_mines=new String[]{"10","36","91"};
private String[] level_time=new String[]{"1","3","10"};



MineSweeper()
{
  test_minesweeper();
}

public void test_minesweeper()
{
main_frm1=new JFrame("MINE SWEEPER");
main_frm1.setVisible(true);
main_frm1.setSize(400,400);
main_frm1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
gui_mines=new JPanel();
gui_mines.setBackground(Color.WHITE);
for(int i=0;i<3;i++)
{
	final int i11=i;
	level_but[i]=new JButton(difficulty[i]);
	level_but[i].addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e) {
         String[] args=new String[]{level_difficulty[i11],level_mines[i11],level_time[i11]};
	      minesweeper_Board.main(args);
	                  }//action performed..
           });//actionListener
	gui_mines.add(level_but[i]);
}//for i=0;i,3
JPanel p1=new JPanel(new GridLayout(0, 9));
p1.setBorder(new LineBorder(Color.BLACK));
gui_mines.add(p1);
main_frm1.add(gui_mines);
}//test method...


public static void main(String args[])
{
	
new MineSweeper();
}

}




class minesweeper_Board {
static int m;
static int mines;
static int tim;

    private final JPanel gui_mines = new JPanel(new BorderLayout(3,3));
    private JButton[][] squares_buttns = new JButton[m][m];
    private JPanel panel_board;
    public int a[][]=new int[mines][2];
    public static JFrame f;
    public JButton b[][]=new JButton[m][m];
    public int flag[][]=new int[m][m];
	public int butn[][]=new int[m][m];
    private JLabel label_timer;
    minesweeper_Board() {

label_timer = new JLabel("10", JLabel.CENTER);
new Timer_minesweeper(label_timer,tim,a,b,flag,mines,m);
final int[] ints = new Random().ints(1, m*m).distinct().limit(mines).toArray();
int l,m1,p=0;
for(int i=0;i<mines;i++){
  
	//System.out.println(ints[i]);
    a[i][0]=ints[i]/m;
	a[i][1]=ints[i]%m;           
  }//for
initializeGui();
 }//board constructor..

public final void initializeGui() {
gui_mines.setBorder(new EmptyBorder(5, 5, 5, 5));
JToolBar tools = new JToolBar();
tools.setFloatable(false);
gui_mines.add(tools, BorderLayout.PAGE_START);
tools.add(new JLabel("TIME:")); // TODO - add functionality!
tools.add(label_timer);
//tools.add(new JLabel(" seconds")); // TODO - add functionality!
panel_board = new JPanel(new GridLayout(0, m));
panel_board.setBorder(new LineBorder(Color.BLACK));
gui_mines.add(panel_board);
// create the chess board squares
Insets buttonMargin = new Insets(0,0,0,0);
for (int p = 0; p < squares_buttns.length; p++) {
	for (int q = 0; q < squares_buttns[p].length; q++) {
		b[p][q] = new JButton("              ");
        final int uu=p;
    	final int vv=q;
		b[uu][vv].setForeground(Color.BLACK);    
		b[uu][vv].setBackground(Color.YELLOW);
		b[uu][vv].setHorizontalTextPosition( SwingConstants.CENTER);
		b[uu][vv].setFont(new Font("Serif", Font.BOLD, 15));//8in place of 15
        b[uu][vv].addMouseListener(new MouseAdapter(){
            boolean pressed;

            @Override
            public void mousePressed(MouseEvent e) {
                b[uu][vv].getModel().setArmed(true);
                b[uu][vv].getModel().setPressed(true);
                pressed = true;
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                //if(isRightButtonPressed) {underlyingButton.getModel().setPressed(true));
                b[uu][vv].getModel().setArmed(false);
                b[uu][vv].getModel().setPressed(false);
          if (pressed && done.getcomple()==0) {
            if (SwingUtilities.isRightMouseButton(e)) {
                        //b[uu][vv].setText("MARK");
                     
			  if(flag[uu][vv]==0 ){
				try {
    			  Image go_btn_img = ImageIO.read(getClass().getResource("image.jpg"));
				  b[uu][vv].setIcon(new ImageIcon(go_btn_img));
				  flag[uu][vv]=1;
				} catch (Exception ex) {
				System.out.println(ex);
				}
				}//if..setIcon
			 else{
				b[uu][vv].setIcon(null);
				flag[uu][vv]=0;
			    }
		  }//if(swingUtilities.isRightButtonPressed)......ends here 
		  //now exploding bomb when bomb button is clicked...
          else
		  {
					butn[uu][vv]=butn[uu][vv]+1;
			int i;
             for(i=0;i<mines;i++)
			 {
				if(a[i][0]==uu && a[i][1]==vv &&flag[uu][vv]==0){
     			int l,m1,j;
			for(j=0;j<mines;j++)
			   {
				l=a[j][0];
				m1=a[j][1];
			if(flag[l][m1]!=1){
				try {
					Image go_btn_img = ImageIO.read(getClass().getResource("bomb.jpg"));
					b[l][m1].setIcon(new ImageIcon(go_btn_img));
					} catch (Exception ex) {
						System.out.println(ex);
					}//try
					}//ifflag
			   }//for j=0,j<mines
            			
		try{
			InputStream in = new FileInputStream("explosion.wav");
					AudioStream as = new AudioStream(in);         
       	   AudioPlayer.player.start(as);  
			}
			catch(Exception excep)
			{
				System.out.println(excep);
			}
			
			for(j=0;j<mines;j++){
				l=a[j][0];
				m1=a[j][1];
	         if(flag[l][m1]!=1){
				try {
					Image go_btn_img = ImageIO.read(getClass().getResource("bomb.jpg"));
					b[l][m1].setIcon(new ImageIcon(go_btn_img)); 
					} catch (Exception ex) {
					System.out.println(ex);
  				}}//ifflag
				else{
					flag[l][m1]=0;
				}
			}//for j in mines,..

			for(int x=0;x<m;x++)
			  {
				for(int y=0;y<m;y++)
				{
					if(flag[x][y]==1)
					{
						try {
					Image go_btn_img = ImageIO.read(getClass().getResource("crossover.jpg"));
					b[x][y].setIcon(new ImageIcon(go_btn_img));
					} catch (Exception ex) {
					System.out.println(ex);
  			       	}//catch
					}//if
				}//for y 
			}//for x
			
	if(done.getcomple()==0)
	{
	JFrame frme_done=new JFrame();
	JButton btn=new JButton();
	try {
	 Image go_btn_img = ImageIO.read(getClass().getResource("gameover.jpg"));
	 done.setcomple(1);
	 btn.setIcon(new ImageIcon(go_btn_img));
	 } catch (Exception ex) {
	   System.out.println(ex);
	  }

	frme_done.getContentPane().add(btn);
	 frme_done. setSize(600,800);
	 frme_done.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frme_done.setVisible(true);
	}  
else{
	
}	
		 }//if                         
		}//for i=0,i<mines
			if(i==mines && flag[uu][vv]!=1 && butn[uu][vv]==1)
				{
			int boundaries_curr[][]={{uu-1,vv-1},{uu-1,vv},{uu-1,vv+1},{uu,vv-1},{uu,vv+1},{uu+1,vv-1},{uu+1,vv},{uu+1,vv+1}};
			int count =0;
			for(int ss=0;ss<mines;ss++)//number of mines
			  {
				for(int cc=0;cc<8;cc++)//neighbours
				{
					if(a[ss][0] == boundaries_curr[cc][0] && a[ss][1] == boundaries_curr[cc][1] )
					count++;			
				}//for
			  }//for
			b[uu][vv].setText(String.valueOf(count));
			}//if(i==m)
				else if(i==mines && flag[uu][vv]!=1 && butn[uu][vv]>1)
				{
					int boundaries_curr[][]={{uu-1,vv-1},{uu-1,vv},{uu-1,vv+1},{uu,vv-1},{uu,vv+1},{uu+1,vv-1},{uu+1,vv},{uu+1,vv+1}};
					
					int count =0;
//yy loop starts...
				for(int yy=0;yy<8;yy++)
				{
					int q=boundaries_curr[yy][0];
					int kk=boundaries_curr[yy][1];
				if(q>=0 && q<m && kk>=0 && kk<m && flag[q][kk]==0)
				{
					int i2;
               for(i2=0;i2<mines;i2++)
			      {
				  if(a[i2][0]==q && a[i2][1]==kk ){
     			   int l,m1,j;
			     for(j=0;j<mines;j++)
			      {
				  l=a[j][0];
				   m1=a[j][1];
			     if(flag[l][m1]!=1){
				      try {
					Image go_btn_img = ImageIO.read(getClass().getResource("bomb.jpg"));
					b[l][m1].setIcon(new ImageIcon(go_btn_img));
					} catch (Exception ex) {
						System.out.println(ex);
					}//try
					}//ifflag
			   }//for j=0,j<mines
            			
		try{
			InputStream in = new FileInputStream("explosion.wav");
					AudioStream as = new AudioStream(in);         
       	   AudioPlayer.player.start(as);  
			}
			catch(Exception excep)
			{
				System.out.println(excep);
			}
			
			
			for(j=0;j<mines;j++){
				l=a[j][0];
				m1=a[j][1];
	         if(flag[l][m1]!=1){
				try {
					Image go_btn_img = ImageIO.read(getClass().getResource("bomb.jpg"));
					b[l][m1].setIcon(new ImageIcon(go_btn_img)); 
					} 
					catch (Exception ex) {
					System.out.println(ex);
  				}
				}//ifflag
				else{
					flag[l][m1]=0;
				}
			}//for j in mines,..

			for(int x=0;x<m;x++)
			  {
				for(int y=0;y<m;y++)
				{
					if(flag[x][y]==1)
					{
						try {
					Image go_btn_img = ImageIO.read(getClass().getResource("crossover.jpg"));
					b[x][y].setIcon(new ImageIcon(go_btn_img));
					} 
					catch (Exception ex) {
					System.out.println(ex);
  			       	}//catch
					}//if
				}//for y 
			}//for x
			
	if(done.getcomple()==0)
	{
	JFrame frme_done=new JFrame();
	JButton btn=new JButton();
	try {
	 Image go_btn_img = ImageIO.read(getClass().getResource("gameover.jpg"));
	 done.setcomple(1);
	 btn.setIcon(new ImageIcon(go_btn_img));
	 }
	 catch (Exception ex) {
	   System.out.println(ex);
	  }

	frme_done.getContentPane().add(btn);
	 frme_done. setSize(600,800);
	 frme_done.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frme_done.setVisible(true);
	}
	else{
		
	}
		   }//if                         
		}//for i=0,i<mines
		if(i==mines)
		{
			int bound[][]={{q-1,kk-1},{q-1,kk},{q-1,kk+1},{q,kk-1},{q,kk+1},{q+1,kk-1},{q+1,kk},{q+1,kk+1}};
			int count1=0;
			for(int ss=0;ss<mines;ss++)//number of mines
			      { 
				  for(int cc=0;cc<8;cc++)//neighbours
				    {
					 if(a[ss][0] == bound[cc][0] && a[ss][1] == bound[cc][1] )
					 count1++;			
				}//for
			  }//for
			b[q][kk].setText(String.valueOf(count1));
		  butn[q][kk]=butn[q][kk]+1;

			}			
			}//if
				}//for yy
				}
			  }		    
           pressed = false;
            }
				}
            @Override
            public void mouseExited(MouseEvent e) {
                pressed = false;
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                pressed = true;
            }                    
        });
                b[uu][vv].setMargin(buttonMargin);
                ImageIcon icon = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
                b[uu][vv].setIcon(icon);  
                squares_buttns[q][p] = b[uu][vv];
                
            }
        }

            for (int p = 1; p < m+1; p++) {
            for (int q = 1; q < m+1; q++) {
                
                        panel_board.add(squares_buttns[q-1][p-1]);
            }
        }
    }
	

    public final JComponent getpanel_board() {
        return panel_board;
    }

    public final JComponent getGui() {
        return gui_mines;
    }

    public static void main(String[] args) {
        Runnable r = new Runnable() {

            @Override
            public void run() {
		 f = new JFrame("MineSweeper");
		 minesweeper_Board.m=Integer.parseInt(args[0]);
		 minesweeper_Board.mines=Integer.parseInt(args[1]);
		  minesweeper_Board.tim=Integer.parseInt(args[2]);
                minesweeper_Board bo = new minesweeper_Board();
              
                f.add(bo.getGui());
                f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                f.setLocationByPlatform(true);

               
                f.pack();
                f.setMinimumSize(f.getSize());
                f.setVisible(true);
            }
        };
        SwingUtilities.invokeLater(r);
    }
}

class Timer_minesweeper {
     private JLabel label_timer;
	 private int tim;
     Timer timer_count;
     int timeleft_insecs ;
      int c=1;
	  int a[][];
	  JButton b[][];
	  int flag[][];
	  int mines;
		int m;
	  public Timer_minesweeper(JLabel passedLabel,int tim,int a[][],JButton	 b[][],int flag[][],int mines,int m) {
        timer_count = new Timer(1000, new Timer_Listener());
        this.label_timer = passedLabel;
		this.tim=tim;
		this.a=a;
		this.b=b;
		this.flag=flag;
		this.mines=mines;
		this.m=m;
		timeleft_insecs=tim*60;
		
        timer_count.start();
     }

class Timer_Listener implements ActionListener {
          public void actionPerformed(ActionEvent e) {
             if (c++ < timeleft_insecs && done.getcomple()==0)
			{
                 label_timer.setText(String.valueOf(c)+"seconds");
              } 
			  else if(c>=timeleft_insecs)
			  {
                 label_timer.setText("Time's up!");
                 timer_count.stop();	
						int l,m1,j;
						for(j=0;j<mines;j++){
							l=a[j][0];
							m1=a[j][1];
						 if(flag[l][m1]!=1){
							try {
								Image go_btn_img = ImageIO.read(getClass().getResource("bomb.jpg"));
								b[l][m1].setIcon(new ImageIcon(go_btn_img)); 
								} catch (Exception ex) {
								System.out.println(ex);
							}
							}//ifflag
							else{
								flag[l][m1]=0;
							}
						}//for j in mines,..
						//sound of explosion
					
					try{
						InputStream in = new FileInputStream("explosion.wav");
								AudioStream as = new AudioStream(in);         
					   AudioPlayer.player.start(as);  
						}
						catch(Exception excep)
						{
							System.out.println(excep);
						}
						
					for(int x=0;x<m;x++)
						{
							for(int y=0;y<m;y++)
							{
								if(flag[x][y]==1)
								{
									try {
								Image go_btn_img = ImageIO.read(getClass().getResource("crossover.jpg"));
								b[x][y].setIcon(new ImageIcon(go_btn_img));
								} catch (Exception ex) {
								System.out.println(ex);
								}//catch
								}//if
							}//for y 
						}//for x
					//Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				  //int height = screenSize.height * 2 / 3;
				  //	int width = screenSize.width * 2 / 3;
					 
					if(done.getcomple()==0)
					{
					JFrame frme_done=new JFrame();
					JButton btn=new JButton();
					try {
						
					 Image go_btn_img = ImageIO.read(getClass().getResource("gameover.jpg"));
					 done.setcomple(1);
					  btn.setIcon(new ImageIcon(go_btn_img));
						}
					 catch (Exception ex) {
					   System.out.println(ex);
										}
						 frme_done.getContentPane().add(btn);
						 frme_done. setSize(600,800);
						 frme_done.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						 frme_done.setVisible(true);
					  }
					  else{
						  
					  }
			  }
			else{
				 
				  label_timer.setText("Time's up!");
                 timer_count.stop();	
											  }
		  }
					  
				  }//method actionPerformed
			  }//class timer_count